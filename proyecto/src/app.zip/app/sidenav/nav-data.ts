export const navbarData = [
    {

        routelink:'dashboard',
        icon: 'fal fa-users',
        label:'Registrados'
    },
    {

        routelink:'products',
        icon: 'fal fa-users',
        label:'Aceptados'
    },
    {

        routelink:'statistics',
        icon: 'fal fa-chart-bar',
        label:'Estadisticas'
    },
    {

        routelink:'coupens',
        icon: 'fal fa-tags',
        label:'Descuentos'
    },
    {

        routelink:'pages',
        icon: 'fal fa-file',
        label:'Principal'
    },
    {

        routelink:'media',
        icon: 'fal fa-camera',
        label:'Autos'
    },
    




];